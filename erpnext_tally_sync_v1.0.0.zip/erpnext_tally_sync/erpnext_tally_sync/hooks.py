app_name        = "erpnext_tally_sync"
app_title       = "ERPNext Tally Sync"
app_publisher   = "AVS Technologies Pvt. Ltd."
app_description = "Sync accounting vouchers from ERPNext to Tally Prime in real-time"
app_icon        = "octicon octicon-sync"
app_color       = "#2490EF"
app_email       = "admin@avstechnologies.in"
app_license     = "MIT"
app_version     = "1.0.0"

# ── Required apps ──────────────────────────────────────────────────────────
required_apps = ["erpnext"]

# ── Fixtures (export these doctypes with bench export-fixtures) ────────────
fixtures = [
    {
        "doctype": "Tally Settings",
        "filters": []
    }
]

# ── DocType events — fire on Submit & Cancel ──────────────────────────────
doc_events = {
    "Sales Invoice": {
        "on_submit": "erpnext_tally_sync.sync_manager.sync_sales_invoice",
        "on_cancel": "erpnext_tally_sync.sync_manager.cancel_sales_invoice",
    },
    "Purchase Invoice": {
        "on_submit": "erpnext_tally_sync.sync_manager.sync_purchase_invoice",
        "on_cancel": "erpnext_tally_sync.sync_manager.cancel_purchase_invoice",
    },
    "Payment Entry": {
        "on_submit": "erpnext_tally_sync.sync_manager.sync_payment_entry",
        "on_cancel": "erpnext_tally_sync.sync_manager.cancel_payment_entry",
    },
    "Journal Entry": {
        "on_submit": "erpnext_tally_sync.sync_manager.sync_journal_entry",
        "on_cancel": "erpnext_tally_sync.sync_manager.cancel_journal_entry",
    },
}

# ── Scheduled jobs (optional background retry of failed syncs) ────────────
scheduler_events = {
    "hourly": [
        "erpnext_tally_sync.sync_manager.retry_failed_syncs",
    ]
}
