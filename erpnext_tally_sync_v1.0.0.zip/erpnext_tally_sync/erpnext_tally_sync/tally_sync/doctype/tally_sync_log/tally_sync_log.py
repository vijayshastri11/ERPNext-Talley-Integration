import frappe
from frappe.model.document import Document


class TallySyncLog(Document):

    @staticmethod
    def create_log(
        reference_doctype: str,
        reference_name: str,
        tally_voucher_type: str,
        xml_payload: str,
        status: str = "Pending",
    ) -> "TallySyncLog":
        doc = frappe.new_doc("Tally Sync Log")
        doc.reference_doctype   = reference_doctype
        doc.reference_name      = reference_name
        doc.tally_voucher_type  = tally_voucher_type
        doc.tally_voucher_number = reference_name
        doc.xml_payload         = xml_payload
        doc.sync_status         = status
        doc.insert(ignore_permissions=True)
        frappe.db.commit()
        return doc

    def mark_success(self, tally_response: str):
        from frappe.utils import now
        self.sync_status    = "Success"
        self.tally_response = tally_response[:5000]
        self.synced_on      = now()
        self.error_message  = ""
        self.save(ignore_permissions=True)
        frappe.db.commit()

    def mark_failed(self, error: str, tally_response: str = ""):
        from frappe.utils import add_to_date, now
        settings = frappe.get_single("Tally Settings")
        self.sync_status    = "Failed"
        self.tally_response = tally_response[:5000]
        self.error_message  = error[:2000]
        self.retry_count    = (self.retry_count or 0) + 1
        self.next_retry_at  = add_to_date(now(), minutes=30 * self.retry_count)
        self.save(ignore_permissions=True)
        frappe.db.commit()
