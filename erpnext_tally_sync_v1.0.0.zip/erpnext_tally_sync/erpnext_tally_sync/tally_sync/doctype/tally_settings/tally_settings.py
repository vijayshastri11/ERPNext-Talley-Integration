import frappe
from frappe.model.document import Document


class TallySettings(Document):

    def validate(self):
        if self.tally_port and not (1 <= int(self.tally_port) <= 65535):
            frappe.throw("Tally Port must be between 1 and 65535.")
        if self.gstin and len(self.gstin) != 15:
            frappe.throw("GSTIN must be exactly 15 characters.")

    @staticmethod
    def get_settings():
        """Convenience method — returns the singleton settings doc."""
        return frappe.get_single("Tally Settings")

    def get_base_url(self):
        return f"http://{self.tally_host}:{self.tally_port}"
