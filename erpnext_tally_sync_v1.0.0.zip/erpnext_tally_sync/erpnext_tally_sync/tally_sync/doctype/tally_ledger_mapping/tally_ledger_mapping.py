import frappe
from frappe.model.document import Document


class TallyLedgerMapping(Document):

    def validate(self):
        if not self.tally_ledger_name.strip():
            frappe.throw("Tally Ledger Name cannot be blank.")

    # ── Static helpers used by tally_xml.py ───────────────────────────────

    @staticmethod
    def get_tally_ledger(erpnext_account: str) -> str:
        """
        Return the mapped Tally ledger name for an ERPNext account.
        Falls back to the ERPNext account name itself if no mapping exists.
        """
        if not erpnext_account:
            return ""
        mapped = frappe.db.get_value(
            "Tally Ledger Mapping",
            {"erpnext_account": erpnext_account},
            "tally_ledger_name",
        )
        return mapped or erpnext_account

    @staticmethod
    def get_all_mappings() -> dict:
        """Return a dict of {erpnext_account: tally_ledger_name} for bulk use."""
        rows = frappe.get_all(
            "Tally Ledger Mapping",
            fields=["erpnext_account", "tally_ledger_name"],
        )
        return {r.erpnext_account: r.tally_ledger_name for r in rows}
