"""
api.py
======
Whitelisted Frappe API endpoints.

Usage from browser / Postman:
  GET  /api/method/erpnext_tally_sync.api.test_connection
  POST /api/method/erpnext_tally_sync.api.manual_sync
       body: { "doctype": "Sales Invoice", "docname": "SINV-0001" }
  POST /api/method/erpnext_tally_sync.api.bulk_sync
       body: { "doctype": "Sales Invoice", "from_date": "2024-01-01", "to_date": "2024-03-31" }
"""

import frappe
import traceback
from frappe import _

from erpnext_tally_sync.tally_xml import (
    build_sales_voucher,
    build_purchase_voucher,
    build_payment_voucher,
    build_journal_voucher,
    post_to_tally,
    _check_tally_response,
)
from erpnext_tally_sync.tally_sync.doctype.tally_sync_log.tally_sync_log import TallySyncLog


_BUILDER_MAP = {
    "Sales Invoice":    ("Sales",    build_sales_voucher),
    "Purchase Invoice": ("Purchase", build_purchase_voucher),
    "Payment Entry":    ("Payment",  build_payment_voucher),
    "Journal Entry":    ("Journal",  build_journal_voucher),
}


# ── Test Connection ────────────────────────────────────────────────────────

@frappe.whitelist()
def test_connection():
    """
    Sends a simple company-list query to Tally to verify connectivity.
    Returns {"status": "ok", "response": "..."} or {"status": "error", "message": "..."}
    """
    ping_xml = """<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>Export</TALLYREQUEST>
    <TYPE>Data</TYPE>
    <ID>List of Companies</ID>
  </HEADER>
  <BODY>
    <EXPORTDATA>
      <REQUESTDESC>
        <REPORTNAME>List of Companies</REPORTNAME>
      </REQUESTDESC>
    </EXPORTDATA>
  </BODY>
</ENVELOPE>"""
    try:
        response = post_to_tally(ping_xml)
        return {"status": "ok", "response": response[:1000]}
    except Exception as exc:
        return {"status": "error", "message": str(exc)}


# ── Manual Single-Document Sync ────────────────────────────────────────────

@frappe.whitelist()
def manual_sync(doctype: str, docname: str):
    """
    Manually (re)sync a single submitted document to Tally.
    Useful for documents that failed on auto-sync.
    """
    frappe.only_for("System Manager")

    if doctype not in _BUILDER_MAP:
        frappe.throw(_(f"DocType '{doctype}' is not supported for Tally sync."))

    doc = frappe.get_doc(doctype, docname)
    if doc.docstatus != 1:
        frappe.throw(_("Only submitted documents can be synced to Tally."))

    vch_type, builder = _BUILDER_MAP[doctype]
    xml = builder(doc)

    log = TallySyncLog.create_log(doctype, docname, vch_type, xml, "Pending")
    try:
        response_text = post_to_tally(xml)
        _check_tally_response(response_text)
        log.mark_success(response_text)
        return {"status": "success", "log": log.name, "response": response_text[:500]}
    except Exception as exc:
        log.mark_failed(str(exc) + "\n" + traceback.format_exc())
        frappe.throw(_(f"Tally sync failed: {exc}"))


# ── Bulk / Backfill Sync ───────────────────────────────────────────────────

@frappe.whitelist()
def bulk_sync(doctype: str, from_date: str, to_date: str):
    """
    Sync all submitted documents of a given type within a date range.
    Returns a summary dict.

    Call via:
      POST /api/method/erpnext_tally_sync.api.bulk_sync
      { "doctype": "Sales Invoice", "from_date": "2024-01-01", "to_date": "2024-03-31" }
    """
    frappe.only_for("System Manager")

    if doctype not in _BUILDER_MAP:
        frappe.throw(_(f"DocType '{doctype}' is not supported for Tally sync."))

    docs = frappe.get_all(
        doctype,
        filters={
            "docstatus": 1,
            "posting_date": ["between", [from_date, to_date]],
        },
        fields=["name"],
        order_by="posting_date asc",
    )

    total   = len(docs)
    success = 0
    failed  = 0
    skipped = 0

    vch_type, builder = _BUILDER_MAP[doctype]

    for row in docs:
        # Skip docs already successfully synced
        already = frappe.db.exists(
            "Tally Sync Log",
            {
                "reference_doctype": doctype,
                "reference_name": row.name,
                "sync_status": "Success",
            },
        )
        if already:
            skipped += 1
            continue

        doc = frappe.get_doc(doctype, row.name)
        xml = builder(doc)
        log = TallySyncLog.create_log(doctype, row.name, vch_type, xml, "Pending")
        try:
            response_text = post_to_tally(xml)
            _check_tally_response(response_text)
            log.mark_success(response_text)
            success += 1
        except Exception as exc:
            log.mark_failed(str(exc) + "\n" + traceback.format_exc())
            failed += 1

    return {
        "doctype": doctype,
        "from_date": from_date,
        "to_date": to_date,
        "total": total,
        "success": success,
        "failed": failed,
        "skipped_already_synced": skipped,
    }


# ── Sync Status for a Document ─────────────────────────────────────────────

@frappe.whitelist()
def get_sync_status(doctype: str, docname: str):
    """Return the latest Tally Sync Log entry for a document."""
    logs = frappe.get_all(
        "Tally Sync Log",
        filters={"reference_doctype": doctype, "reference_name": docname},
        fields=["name", "sync_status", "synced_on", "tally_voucher_type",
                "retry_count", "error_message"],
        order_by="creation desc",
        limit=5,
    )
    return logs
