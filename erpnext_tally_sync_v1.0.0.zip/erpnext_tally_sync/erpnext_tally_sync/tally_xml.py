"""
tally_xml.py
============
Builds Tally Prime TDL/XML Import payloads for all voucher types.

Encoding note: Tally Prime expects UTF-16 LE by default.
The post_to_tally() function handles encoding automatically.
"""

import frappe
import requests
import traceback
from datetime import datetime


# ── Helpers ────────────────────────────────────────────────────────────────

def _get_settings():
    return frappe.get_single("Tally Settings")


def _fmt_date(date_val) -> str:
    """Convert Python date / date-string (YYYY-MM-DD) → Tally format (YYYYMMDD)."""
    if not date_val:
        return ""
    if isinstance(date_val, str):
        date_val = datetime.strptime(date_val[:10], "%Y-%m-%d")
    return date_val.strftime("%Y%m%d")


def _fmt_amount(amount) -> str:
    """Format a numeric amount to 2 decimal places as string."""
    try:
        return f"{abs(float(amount)):.2f}"
    except (TypeError, ValueError):
        return "0.00"


def _get_ledger(account: str) -> str:
    """Look up Tally ledger name from ERPNext account, fall back to account itself."""
    from erpnext_tally_sync.tally_sync.doctype.tally_ledger_mapping.tally_ledger_mapping import (
        TallyLedgerMapping,
    )
    return TallyLedgerMapping.get_tally_ledger(account)


def _envelope(company: str, voucher_xml: str) -> str:
    """Wrap a voucher XML block in the standard Tally Import envelope."""
    return f"""<ENVELOPE>
  <HEADER>
    <TALLYREQUEST>Import Data</TALLYREQUEST>
  </HEADER>
  <BODY>
    <IMPORTDATA>
      <REQUESTDESC>
        <REPORTNAME>Vouchers</REPORTNAME>
        <STATICVARIABLES>
          <SVCURRENTCOMPANY>{company}</SVCURRENTCOMPANY>
        </STATICVARIABLES>
      </REQUESTDESC>
      <REQUESTDATA>
        <TALLYMESSAGE xmlns:UDF="TallyUDF">
          {voucher_xml}
        </TALLYMESSAGE>
      </REQUESTDATA>
    </IMPORTDATA>
  </BODY>
</ENVELOPE>"""


def _delete_envelope(company: str, vch_type: str, vch_number: str) -> str:
    """Build a DELETE action envelope to cancel/remove a Tally voucher."""
    voucher_xml = f"""<VOUCHER VCHTYPE="{vch_type}" ACTION="Delete">
            <VOUCHERTYPENAME>{vch_type}</VOUCHERTYPENAME>
            <VOUCHERNUMBER>{vch_number}</VOUCHERNUMBER>
          </VOUCHER>"""
    return _envelope(company, voucher_xml)


def _ledger_entry(ledger: str, is_debit: bool, amount: float) -> str:
    """Build a single <ALLLEDGERENTRIES.LIST> XML node."""
    # In Tally convention:
    #   ISDEEMEDPOSITIVE = Yes  → debit  (positive effect on the account)
    #   ISDEEMEDPOSITIVE = No   → credit (negative; Tally stores as negative)
    deemed = "Yes" if is_debit else "No"
    signed_amount = _fmt_amount(amount) if is_debit else f"-{_fmt_amount(amount)}"
    return f"""<ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>{ledger}</LEDGERNAME>
              <ISDEEMEDPOSITIVE>{deemed}</ISDEEMEDPOSITIVE>
              <AMOUNT>{signed_amount}</AMOUNT>
            </ALLLEDGERENTRIES.LIST>"""


# ── HTTP transport ─────────────────────────────────────────────────────────

def post_to_tally(xml_payload: str) -> str:
    """
    POST xml_payload to Tally Prime gateway.
    Returns raw response text.
    Raises requests.RequestException on connection failures.
    """
    settings = _get_settings()
    url      = f"http://{settings.tally_host}:{settings.tally_port}"
    timeout  = int(settings.request_timeout or 30)
    encoding = settings.encoding or "utf-16"

    encoded_payload = xml_payload.encode(encoding)
    headers = {
        "Content-Type": f"text/xml; charset={encoding}",
        "Content-Length": str(len(encoded_payload)),
    }
    response = requests.post(
        url,
        data=encoded_payload,
        headers=headers,
        timeout=timeout,
    )
    response.raise_for_status()
    return response.text


def _check_tally_response(response_text: str):
    """
    Raise an exception if Tally returned an error in its XML response.
    Tally signals errors with <LINEERROR> or <STATUS>0</STATUS> in the body.
    """
    if not response_text:
        raise ValueError("Empty response from Tally Prime")
    if "<LINEERROR>" in response_text:
        import re
        errors = re.findall(r"<LINEERROR>(.*?)</LINEERROR>", response_text)
        raise ValueError(f"Tally reported errors: {'; '.join(errors)}")
    if "<STATUS>0</STATUS>" in response_text:
        raise ValueError(f"Tally returned STATUS=0 (failure). Response: {response_text[:500]}")


# ══════════════════════════════════════════════════════════════════════════
#  SALES INVOICE
# ══════════════════════════════════════════════════════════════════════════

def build_sales_voucher(doc, action: str = "Create") -> str:
    """Build Tally Sales voucher XML from an ERPNext Sales Invoice doc."""
    company       = doc.company
    customer_ledger = _get_ledger(doc.debit_to)   # Receivable account
    customer_name   = doc.customer

    # --- Line items (income ledgers) ---
    ledger_entries = ""
    for item in doc.items:
        income_ledger = _get_ledger(item.income_account)
        ledger_entries += _ledger_entry(income_ledger, is_debit=False, amount=item.net_amount)

    # --- Tax entries ---
    for tax in (doc.taxes or []):
        tax_ledger = _get_ledger(tax.account_head)
        ledger_entries += _ledger_entry(tax_ledger, is_debit=False, amount=tax.tax_amount)

    # --- Debit the receivable (customer) side ---
    ledger_entries = (
        _ledger_entry(customer_ledger, is_debit=True, amount=doc.grand_total)
        + ledger_entries
    )

    narration = (doc.remarks or f"ERPNext Sales Invoice: {doc.name}")

    voucher_xml = f"""<VOUCHER VCHTYPE="Sales" ACTION="{action}">
            <DATE>{_fmt_date(doc.posting_date)}</DATE>
            <VOUCHERTYPENAME>Sales</VOUCHERTYPENAME>
            <VOUCHERNUMBER>{doc.name}</VOUCHERNUMBER>
            <PARTYLEDGERNAME>{customer_name}</PARTYLEDGERNAME>
            <NARRATION>{narration}</NARRATION>
            <ISINVOICE>Yes</ISINVOICE>
            {ledger_entries}
          </VOUCHER>"""
    return _envelope(company, voucher_xml)


def build_sales_cancel(doc) -> str:
    return _delete_envelope(doc.company, "Sales", doc.name)


# ══════════════════════════════════════════════════════════════════════════
#  PURCHASE INVOICE
# ══════════════════════════════════════════════════════════════════════════

def build_purchase_voucher(doc, action: str = "Create") -> str:
    """Build Tally Purchase voucher XML from an ERPNext Purchase Invoice doc."""
    company        = doc.company
    payable_ledger = _get_ledger(doc.credit_to)
    supplier_name  = doc.supplier

    ledger_entries = ""
    for item in doc.items:
        expense_ledger = _get_ledger(item.expense_account)
        ledger_entries += _ledger_entry(expense_ledger, is_debit=True, amount=item.net_amount)

    for tax in (doc.taxes or []):
        tax_ledger = _get_ledger(tax.account_head)
        ledger_entries += _ledger_entry(tax_ledger, is_debit=True, amount=tax.tax_amount)

    # Credit the payable (supplier) side
    ledger_entries += _ledger_entry(payable_ledger, is_debit=False, amount=doc.grand_total)

    narration = (doc.remarks or f"ERPNext Purchase Invoice: {doc.name}")

    voucher_xml = f"""<VOUCHER VCHTYPE="Purchase" ACTION="{action}">
            <DATE>{_fmt_date(doc.posting_date)}</DATE>
            <VOUCHERTYPENAME>Purchase</VOUCHERTYPENAME>
            <VOUCHERNUMBER>{doc.name}</VOUCHERNUMBER>
            <PARTYLEDGERNAME>{supplier_name}</PARTYLEDGERNAME>
            <NARRATION>{narration}</NARRATION>
            <ISINVOICE>Yes</ISINVOICE>
            {ledger_entries}
          </VOUCHER>"""
    return _envelope(company, voucher_xml)


def build_purchase_cancel(doc) -> str:
    return _delete_envelope(doc.company, "Purchase", doc.name)


# ══════════════════════════════════════════════════════════════════════════
#  PAYMENT ENTRY  (covers both Payment & Receipt)
# ══════════════════════════════════════════════════════════════════════════

def build_payment_voucher(doc, action: str = "Create") -> str:
    """
    Build Tally Payment or Receipt voucher XML from an ERPNext Payment Entry.

    ERPNext payment_type:
        'Receive'  → Tally Receipt   (money coming in from customer)
        'Pay'      → Tally Payment   (money going out to supplier)
        'Internal Transfer' → Tally Contra
    """
    ptype_map = {
        "Receive":            "Receipt",
        "Pay":                "Payment",
        "Internal Transfer":  "Contra",
    }
    vch_type = ptype_map.get(doc.payment_type, "Journal")
    company  = doc.company

    paid_from_ledger = _get_ledger(doc.paid_from)
    paid_to_ledger   = _get_ledger(doc.paid_to)
    party_ledger     = _get_ledger(doc.party_account) if doc.party_account else doc.party

    amount = doc.paid_amount

    if vch_type == "Receipt":
        # Debit bank/cash (paid_to), Credit party (paid_from / debtor side)
        ledger_entries = (
            _ledger_entry(paid_to_ledger, is_debit=True, amount=amount)
            + _ledger_entry(paid_from_ledger, is_debit=False, amount=amount)
        )
        party = doc.party  # customer
    elif vch_type == "Payment":
        # Credit bank/cash (paid_from), Debit party payable (paid_to / creditor)
        ledger_entries = (
            _ledger_entry(paid_to_ledger, is_debit=True, amount=amount)
            + _ledger_entry(paid_from_ledger, is_debit=False, amount=amount)
        )
        party = doc.party  # supplier
    else:  # Contra / Internal Transfer
        ledger_entries = (
            _ledger_entry(paid_to_ledger, is_debit=True, amount=amount)
            + _ledger_entry(paid_from_ledger, is_debit=False, amount=amount)
        )
        party = ""

    narration = (doc.remarks or f"ERPNext Payment Entry: {doc.name}")

    voucher_xml = f"""<VOUCHER VCHTYPE="{vch_type}" ACTION="{action}">
            <DATE>{_fmt_date(doc.posting_date)}</DATE>
            <VOUCHERTYPENAME>{vch_type}</VOUCHERTYPENAME>
            <VOUCHERNUMBER>{doc.name}</VOUCHERNUMBER>
            <PARTYLEDGERNAME>{party}</PARTYLEDGERNAME>
            <NARRATION>{narration}</NARRATION>
            {ledger_entries}
          </VOUCHER>"""
    return _envelope(company, voucher_xml)


def build_payment_cancel(doc) -> str:
    ptype_map = {
        "Receive": "Receipt",
        "Pay": "Payment",
        "Internal Transfer": "Contra",
    }
    vch_type = ptype_map.get(doc.payment_type, "Journal")
    return _delete_envelope(doc.company, vch_type, doc.name)


# ══════════════════════════════════════════════════════════════════════════
#  JOURNAL ENTRY
# ══════════════════════════════════════════════════════════════════════════

def build_journal_voucher(doc, action: str = "Create") -> str:
    """Build a Tally Journal voucher from an ERPNext Journal Entry."""
    company = doc.company
    ledger_entries = ""

    for row in doc.accounts:
        debit  = float(row.debit_in_account_currency  or 0)
        credit = float(row.credit_in_account_currency or 0)
        ledger = _get_ledger(row.account)

        if debit > 0:
            ledger_entries += _ledger_entry(ledger, is_debit=True,  amount=debit)
        if credit > 0:
            ledger_entries += _ledger_entry(ledger, is_debit=False, amount=credit)

    narration = (doc.user_remark or doc.remark or f"ERPNext Journal Entry: {doc.name}")

    voucher_xml = f"""<VOUCHER VCHTYPE="Journal" ACTION="{action}">
            <DATE>{_fmt_date(doc.posting_date)}</DATE>
            <VOUCHERTYPENAME>Journal</VOUCHERTYPENAME>
            <VOUCHERNUMBER>{doc.name}</VOUCHERNUMBER>
            <NARRATION>{narration}</NARRATION>
            {ledger_entries}
          </VOUCHER>"""
    return _envelope(company, voucher_xml)


def build_journal_cancel(doc) -> str:
    return _delete_envelope(doc.company, "Journal", doc.name)
