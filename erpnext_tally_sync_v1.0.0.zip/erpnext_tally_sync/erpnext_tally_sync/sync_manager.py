"""
sync_manager.py
===============
Orchestration layer wired to ERPNext doc_events in hooks.py.
Each public function is called by ERPNext on submit / cancel.

Error strategy
--------------
- On connection failure  → log as Failed, allow ERPNext submit to proceed
  (accounting entry is recorded in ERPNext; Tally sync retried later).
- On Tally LINEERROR     → log as Failed, notify Accounts Manager via ERPNext alert.
- retry_failed_syncs()   → scheduled hourly, retries up to max_retries.
"""

import frappe
import traceback

from erpnext_tally_sync.tally_xml import (
    # Builders
    build_sales_voucher,    build_sales_cancel,
    build_purchase_voucher, build_purchase_cancel,
    build_payment_voucher,  build_payment_cancel,
    build_journal_voucher,  build_journal_cancel,
    # Transport
    post_to_tally,
    _check_tally_response,
)
from erpnext_tally_sync.tally_sync.doctype.tally_sync_log.tally_sync_log import TallySyncLog


# ── Internal dispatcher ────────────────────────────────────────────────────

def _sync(doc, voucher_type: str, xml_payload: str):
    """
    Core: post XML to Tally, write Tally Sync Log, surface errors gracefully.
    """
    settings = frappe.get_single("Tally Settings")
    if not settings.enabled:
        return
    if not settings.sync_on_submit:
        # Just create a Pending log; scheduled job will pick it up
        TallySyncLog.create_log(doc.doctype, doc.name, voucher_type, xml_payload, "Pending")
        return

    log = TallySyncLog.create_log(doc.doctype, doc.name, voucher_type, xml_payload, "Pending")

    try:
        response_text = post_to_tally(xml_payload)
        _check_tally_response(response_text)
        log.mark_success(response_text)
        frappe.msgprint(
            f"✅ Tally Sync successful for {doc.name} ({voucher_type})",
            alert=True,
            indicator="green",
        )
    except Exception as exc:
        err_msg = traceback.format_exc()
        log.mark_failed(str(exc) + "\n" + err_msg)
        frappe.log_error(
            title=f"Tally Sync Failed — {doc.name}",
            message=err_msg,
        )
        frappe.msgprint(
            f"⚠️ Tally Sync failed for {doc.name}. The entry is saved in ERPNext. "
            f"Check <b>Tally Sync Log</b> for details. Error: {exc}",
            alert=True,
            indicator="orange",
        )
        # Do NOT re-raise — let ERPNext submit succeed regardless


def _cancel(doc, voucher_type: str, xml_payload: str):
    """Post a DELETE action to Tally on ERPNext cancel."""
    settings = frappe.get_single("Tally Settings")
    if not settings.enabled:
        return

    # Mark existing log as Cancelled
    existing_logs = frappe.get_all(
        "Tally Sync Log",
        filters={"reference_doctype": doc.doctype, "reference_name": doc.name},
        fields=["name"],
    )
    for row in existing_logs:
        frappe.db.set_value("Tally Sync Log", row.name, "sync_status", "Cancelled")

    try:
        response_text = post_to_tally(xml_payload)
        _check_tally_response(response_text)
    except Exception as exc:
        frappe.log_error(
            title=f"Tally Cancel Sync Failed — {doc.name}",
            message=traceback.format_exc(),
        )
        frappe.msgprint(
            f"⚠️ Tally cancel-sync failed for {doc.name}. Please delete manually in Tally. "
            f"Error: {exc}",
            alert=True,
            indicator="orange",
        )

    frappe.db.commit()


# ── Sales Invoice ─────────────────────────────────────────────────────────

def sync_sales_invoice(doc, method):
    xml = build_sales_voucher(doc)
    _sync(doc, "Sales", xml)


def cancel_sales_invoice(doc, method):
    xml = build_sales_cancel(doc)
    _cancel(doc, "Sales", xml)


# ── Purchase Invoice ──────────────────────────────────────────────────────

def sync_purchase_invoice(doc, method):
    xml = build_purchase_voucher(doc)
    _sync(doc, "Purchase", xml)


def cancel_purchase_invoice(doc, method):
    xml = build_purchase_cancel(doc)
    _cancel(doc, "Purchase", xml)


# ── Payment Entry ─────────────────────────────────────────────────────────

def sync_payment_entry(doc, method):
    xml = build_payment_voucher(doc)
    ptype_map = {"Receive": "Receipt", "Pay": "Payment", "Internal Transfer": "Contra"}
    vch_type = ptype_map.get(doc.payment_type, "Journal")
    _sync(doc, vch_type, xml)


def cancel_payment_entry(doc, method):
    xml = build_payment_cancel(doc)
    ptype_map = {"Receive": "Receipt", "Pay": "Payment", "Internal Transfer": "Contra"}
    vch_type = ptype_map.get(doc.payment_type, "Journal")
    _cancel(doc, vch_type, xml)


# ── Journal Entry ─────────────────────────────────────────────────────────

def sync_journal_entry(doc, method):
    xml = build_journal_voucher(doc)
    _sync(doc, "Journal", xml)


def cancel_journal_entry(doc, method):
    xml = build_journal_cancel(doc)
    _cancel(doc, "Journal", xml)


# ── Scheduled Retry ───────────────────────────────────────────────────────

def retry_failed_syncs():
    """
    Hourly scheduled job: retry all Failed logs that are within max_retries limit.
    """
    settings = frappe.get_single("Tally Settings")
    if not settings.enabled:
        return

    max_retries = int(settings.max_retries or 3)
    from frappe.utils import now

    failed_logs = frappe.get_all(
        "Tally Sync Log",
        filters={
            "sync_status": "Failed",
            "retry_count": ["<", max_retries],
            "next_retry_at": ["<=", now()],
        },
        fields=["name", "reference_doctype", "reference_name",
                "tally_voucher_type", "xml_payload", "retry_count"],
    )

    for row in failed_logs:
        log = frappe.get_doc("Tally Sync Log", row.name)
        try:
            response_text = post_to_tally(log.xml_payload)
            _check_tally_response(response_text)
            log.mark_success(response_text)
            frappe.logger().info(
                f"Tally Retry SUCCESS: {log.reference_name} (Log: {log.name})"
            )
        except Exception as exc:
            log.mark_failed(str(exc) + "\n" + traceback.format_exc())
            frappe.logger().warning(
                f"Tally Retry FAILED: {log.reference_name} "
                f"(attempt {log.retry_count}/{max_retries}) — {exc}"
            )
